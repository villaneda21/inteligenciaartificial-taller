import replicate
import os
import requests 
import time  
import sys

def generate_audio():
    # --- 1. CONFIGURACIÓN DEL TOKEN DE API ---
    # Tu token de API. Es buena práctica usar variables de entorno.
    REPLICATE_API_TOKEN = "r8_3b9YTVSzL5mcHEzcWi9Qnca5A8D1BLG1IpEko"
    os.environ["REPLICATE_API_TOKEN"] = REPLICATE_API_TOKEN
    # -------------------------------------------
    
    # --- 2. CONFIGURACIÓN DE LA RUTA DE SALIDA ---
    # La ruta base donde se encuentra tu proyecto (asumiendo que este script está en 'replicate/scripts')
    # Retrocedemos un nivel para llegar a la carpeta 'replicate'
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # Definimos la carpeta de salida para el audio
    OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs", "audio") 
    
    # Crea la carpeta si no existe
    try:
        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
        print(f"📁 Los archivos de audio se guardarán en: {OUTPUT_FOLDER}")
    except OSError as e:
        print(f"❌ Error al crear la carpeta de salida: {e}")
        # Si la carpeta no se puede crear, salimos.
        sys.exit(1)


    # --- 3. SOLICITAR EL PROMPT AL USUARIO ---
    print("\n---------------------------------------------------------")
    print("🎧 Generador de Música con Stable Audio 2.5 (90 segundos) 🎧")
    print("---------------------------------------------------------")
    
    # Solicitamos la descripción de la música
    user_prompt = input("👉 Introduce el prompt (descripción de la música/sonido) que quieres generar: \n> ")
    
    # --- 4. GENERAR NOMBRE DE ARCHIVO ÚNICO ---
    # Usamos una marca de tiempo para garantizar unicidad.
    timestamp = int(time.time())
    # Stable Audio 2.5 genera MP3 por defecto
    output_filename = f"audio_{timestamp}.mp3"
    
    # Combina la ruta de la carpeta con el nombre de archivo
    full_output_path = os.path.join(OUTPUT_FOLDER, output_filename)
    # -------------------------------------------
    
    # Crea una instancia del cliente Replicate
    client = replicate.Client()
    
    # Define los parámetros del modelo
    model_name = "stability-ai/stable-audio-2.5"

    # Define los inputs, usando el prompt proporcionado por el usuario
    model_input = {
        "steps": 8,
        "prompt": user_prompt, # ¡USANDO EL INPUT DEL USUARIO AQUÍ!
        "duration": 90, # 90 segundos de duración, como en el ejemplo
        "cfg_scale": 1
    }

    print(f"\n⏳ Iniciando la generación del audio para el prompt: '{user_prompt}'...")
    
    try:
        # --- 5. Ejecutar el modelo ---
        # ATENCIÓN: Los modelos de audio tardan varios minutos en ejecutarse. ¡Sé paciente!
        output = client.run(
            model_name,
            input=model_input
        )
        
        # --- 6. Procesar la Salida (URL del archivo de audio) ---
        # El output es la URL del archivo de audio generado, ya sea como lista o string.
        if isinstance(output, list) and output:
            audio_url = output[0]
        else:
            audio_url = str(output)
            
        print(f"\n✅ Audio generado con éxito. URL: {audio_url}")

        # --- 7. Descargar y guardar el audio en la ruta específica ---
        print(f"Descargando audio y guardándolo como: {full_output_path}")
        
        response = requests.get(audio_url, stream=True)
        response.raise_for_status()

        # Escribe el contenido en el archivo
        with open(full_output_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)

        print(f"\n🎶 El archivo de audio ha sido guardado en: {full_output_path}")

    except Exception as e:
        print(f"\n❌ Ocurrió un error al ejecutar el modelo o descargar el audio: {e}")
        print("Asegúrate de que tu token de API sea correcto y que el prompt no contenga contenido prohibido.")

if __name__ == "__main__":
    generate_audio()