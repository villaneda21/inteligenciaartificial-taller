import replicate
import os
import requests 
import time  
import sys
import datetime # Para registrar la fecha y hora en el reporte

# --- FUNCIÓN PARA GENERAR EL REPORTE DE LATENCIA ---
def log_report(user_prompt, execution_time, image_path):
    """
    Registra el historial de la generación de imágenes, incluyendo
    la latencia del proceso, en un archivo de texto.
    """
    # Definimos la carpeta de reportes (ej: replicate/outputs/reports)
    # BASE_DIR apunta a la carpeta 'replicate'
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    REPORT_FOLDER = os.path.join(BASE_DIR, "outputs", "reports")
    # Este archivo es específico para el historial de imágenes
    REPORT_FILE = os.path.join(REPORT_FOLDER, "image_history.txt")

    # Aseguramos que la carpeta de reportes exista
    os.makedirs(REPORT_FOLDER, exist_ok=True)
    
    # Formateamos los datos
    timestamp_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    time_taken_str = f"{execution_time:.2f} segundos"
    
    # Contenido del reporte
    report_entry = f"""
--- Reporte de Generación de Imagen ---
Fecha y Hora: {timestamp_str}
Prompt Utilizado: {user_prompt}
Latencia Total del Proceso (Replicate + Descarga): {time_taken_str}
Ruta del Archivo Guardado: {image_path}
------------------------------------
"""
    
    # Escribimos en el archivo de reporte, añadiendo al final (a de append)
    try:
        with open(REPORT_FILE, "a", encoding="utf-8") as f:
            f.write(report_entry)
        print(f"\n📝 Reporte de latencia guardado en: {REPORT_FILE}")
    except Exception as e:
        print(f"❌ Error al guardar el reporte: {e}")


def generate_image():
    # --- 1. CONFIGURACIÓN DEL TOKEN DE API ---
    # Tu token de API. ¡Mantén esta información segura!
    REPLICATE_API_TOKEN = "r8_3b9YTVSzL5mcHEzcWi9Qnca5A8D1BLG1IpEko"
    os.environ["REPLICATE_API_TOKEN"] = REPLICATE_API_TOKEN
    # -------------------------------------------
    
    # --- 2. CONFIGURACIÓN DE LA RUTA DE SALIDA ---
    # La ruta base donde se encuentra tu proyecto 
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs", "images") 
    
    # Crea la carpeta si no existe
    try:
        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
        print(f"📁 Las imágenes se guardarán en: {OUTPUT_FOLDER}")
    except OSError as e:
        print(f"❌ Error al crear la carpeta de salida: {e}")
        sys.exit(1)


    # --- 3. SOLICITAR EL PROMPT AL USUARIO ---
    print("\n-----------------------------------------------------")
    print("🎨 Generador de Imágenes con Stable Diffusion 3.5 🎨")
    print("-----------------------------------------------------")
    
    user_prompt = input("👉 Introduce el prompt (descripción) de la imagen que quieres generar: \n> ")
    
    # --- 4. GENERAR NOMBRE DE ARCHIVO ÚNICO ---
    timestamp = int(time.time())
    output_filename = f"image_{timestamp}.webp" # Extensión por defecto del modelo
    
    full_output_path = os.path.join(OUTPUT_FOLDER, output_filename)
    # -------------------------------------------
    
    client = replicate.Client()
    
    model_name = "stability-ai/stable-diffusion-3.5-large"
    
    model_input = {
        "cfg": 4.5,
        "prompt": user_prompt,
        "aspect_ratio": "1:1",
        "output_format": "webp",
        "prompt_strength": 0.85
    }

    print(f"\n🤖 Iniciando la generación del prompt: '{user_prompt}'...")
    
    # --- INICIO DE LA MEDICIÓN DE TIEMPO ---
    start_time = time.time()
    
    try:
        # --- 5. Ejecutar el modelo ---
        output = client.run(
            model_name,
            input=model_input
        )
        
        # --- 6. Procesar la Salida (URL del archivo) ---
        # Usamos la lógica robusta para obtener la URL
        if isinstance(output, list) and output:
            image_url = output[0]
        else:
            image_url = str(output)
            
        print(f"\n✅ Imagen generada con éxito. URL: {image_url}")

        # --- 7. Descargar y guardar la imagen en la ruta específica ---
        print(f"Descargando imagen y guardándola como: {full_output_path}")
        
        response = requests.get(image_url, stream=True)
        response.raise_for_status()

        with open(full_output_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)

        # --- FIN DE LA MEDICIÓN DE TIEMPO ---
        end_time = time.time()
        execution_time = end_time - start_time
        
        print(f"\n🖼️ La imagen ha sido guardada en: {full_output_path}")
        print(f"⏱️ Tiempo total de ejecución (generación + descarga): {execution_time:.2f} segundos")
        
        # --- 8. GENERAR EL REPORTE ---
        log_report(user_prompt, execution_time, full_output_path)

    except Exception as e:
        print(f"\n❌ Ocurrió un error al ejecutar el modelo o descargar la imagen: {e}")
        print("Asegúrate de que tu token de API sea correcto y que el prompt no contenga contenido prohibido.")

if __name__ == "__main__":
    generate_image()
